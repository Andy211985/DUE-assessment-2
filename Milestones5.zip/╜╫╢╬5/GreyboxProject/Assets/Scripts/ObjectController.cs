using UnityEngine;
using UnityEngine.UIElements;

public class ObjectController : MonoBehaviour
{

    public Transform go;
    private Vector3 initialPosition;
    private Quaternion initialRotation;
    private Vector3 initialScale;
    private const float MaxScaleFactor = 1.7f;
    private const float MinScaleFactor = 0.3f;
    void Start()
    {
        // ��¼��ʼλ�ú���ת
        initialPosition = go.transform.position;
        initialRotation = go.transform.rotation;
        initialScale = go.transform.localScale;
    }

    // ������ת 15 ��
    public void RotateLeft()
    {
        go.transform.Rotate(Vector3.up, -15f);
    }

    // ������ת 15 ��
    public void RotateRight()
    {
        go.transform.Rotate(Vector3.up, 15f);
    }

    // ����������ƶ� 0.1
    public void MoveLeft()
    {
        go.transform.Translate(Vector3.left * 0.2f);
    }

    // �������Ҳ��ƶ� 0.1
    public void MoveRight()
    {
        go.transform.Translate(Vector3.right * 0.2f);
    }

    // �ָ���ʼ�ǶȺ�λ��
    public void ResetPositionAndRotation()
    {
        go.transform.position = initialPosition;
        go.transform.rotation = initialRotation;
    }

    // ��� 10%
    public void ScaleUp()
    {
        Vector3 newScale = go.transform.localScale * 1.1f;
        if (newScale.magnitude <= initialScale.magnitude * MaxScaleFactor)
        {
            go.transform.localScale = newScale;
        }
    }

    // ��С 10%
    public void ScaleDown()
    {
        Vector3 newScale = go.transform.localScale * 0.9f;
        if (newScale.magnitude >= initialScale.magnitude * MinScaleFactor)
        {
            go.transform.localScale = newScale;
        }
    }

}